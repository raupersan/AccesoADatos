package ej2;

public class Libros {
	private String titulo;
	private String autor;
	private int precio;

	public Libros(String titulo, String autor, int precio) {
		super();
		this.titulo = titulo;
		this.autor = autor;
		this.precio = precio;
	}

}
