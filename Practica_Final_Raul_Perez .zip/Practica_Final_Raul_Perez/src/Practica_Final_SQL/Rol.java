package Practica_Final_SQL;

public class Rol {
	enum rol {
		Administrador,
		Empleado,
		Cliente
	};
}
